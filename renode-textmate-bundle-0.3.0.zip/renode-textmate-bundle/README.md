# Renode .repl / .resc — TextMate bundle

Syntax highlighting for Renode platform descriptions and Monitor scripts in
JetBrains IDEs (Rider, IntelliJ IDEA, CLion, PyCharm, ...).

## Install

1. **Settings / Preferences -> Editor -> TextMate Bundles**
2. Press **+** and select this folder (unzip it first if you downloaded the zip).
3. Press **OK**, then reopen any `.repl` or `.resc` file.

Colours follow the TextMate scopes under
**Settings -> Editor -> Color Scheme -> TextMate**, not the VS Code theme.

Version 0.3.0. Generated from the VS Code extension's
grammars, which are identical.
